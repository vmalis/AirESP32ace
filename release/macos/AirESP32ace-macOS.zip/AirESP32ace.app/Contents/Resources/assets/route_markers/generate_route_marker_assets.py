# AirESP32ace
# Created by VM, August 2026

from pathlib import Path

from PIL import Image, ImageDraw


OUT = Path(__file__).resolve().parent
SOURCE_SIZE = (956, 1124)
SCALE = 4

GREY = "#96999a"
WHITE = "#fbfbf8"
RED = "#e63922"

SLENDER_BOUNDS = (55, 122, 167, 967)
BEACON_BOUNDS = (309, 464, 545, 964)
ARROW_BOUNDS = (676, 89, 906, 979)


def rgba(hex_color):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i : i + 2], 16) for i in (0, 2, 4)) + (255,)


def sp(points):
    return [(round(x * SCALE), round(y * SCALE)) for x, y in points]


def qpoints(p0, p1, p2, steps=12):
    pts = []
    for i in range(steps + 1):
        t = i / steps
        x = (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t**2 * p2[0]
        y = (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t**2 * p2[1]
        pts.append((x, y))
    return pts


def cpoints(p0, p1, p2, p3, steps=16):
    pts = []
    for i in range(steps + 1):
        t = i / steps
        x = (
            (1 - t) ** 3 * p0[0]
            + 3 * (1 - t) ** 2 * t * p1[0]
            + 3 * (1 - t) * t**2 * p2[0]
            + t**3 * p3[0]
        )
        y = (
            (1 - t) ** 3 * p0[1]
            + 3 * (1 - t) ** 2 * t * p1[1]
            + 3 * (1 - t) * t**2 * p2[1]
            + t**3 * p3[1]
        )
        pts.append((x, y))
    return pts


def rect(x0, y0, x1, y1):
    return tuple(round(v * SCALE) for v in (x0, y0, x1, y1))


def new_canvas(width=SOURCE_SIZE[0], height=SOURCE_SIZE[1]):
    return Image.new("RGBA", (width * SCALE, height * SCALE), (0, 0, 0, 0))


def downsample(img, size):
    return img.resize(size, Image.Resampling.LANCZOS)


def crop_and_save(canvas, bounds, name):
    crop = canvas.crop(tuple(v * SCALE for v in bounds))
    downsample(crop, (bounds[2] - bounds[0], bounds[3] - bounds[1])).save(OUT / name)


def draw_slender(d):
    grey = rgba(GREY)
    white = rgba(WHITE)

    # Original outer bounds: x 55..167, y 122..967.
    outer = (
        [(103, 122), (156, 290), (156, 914)]
        + qpoints((156, 914), (156, 954), (111, 967), 16)[1:]
        + qpoints((111, 967), (55, 954), (55, 914), 16)[1:]
        + [(55, 290)]
    )
    d.polygon(sp(outer), fill=grey)

    inner = (
        [(80, 314), (80, 872)]
        + qpoints((80, 872), (107, 904), (134, 872), 14)[1:]
        + [(134, 314)]
        + qpoints((134, 314), (107, 296), (80, 314), 14)[1:]
    )
    d.polygon(sp(inner), fill=white)


def draw_beacon(d):
    grey = rgba(GREY)
    white = rgba(WHITE)

    # Original outer bounds: x 309..545, y 464..964.
    outer = []
    outer += [(423, 464)]
    outer += cpoints((423, 464), (451, 520), (462, 562), (478, 585), 10)[1:]
    outer += cpoints((478, 585), (522, 605), (545, 648), (545, 696), 16)[1:]
    outer += cpoints((545, 696), (545, 744), (519, 781), (476, 807), 16)[1:]
    outer += [(476, 944)]
    outer += qpoints((476, 944), (476, 964), (456, 964), 8)[1:]
    outer += [(390, 964)]
    outer += qpoints((390, 964), (370, 964), (370, 944), 8)[1:]
    outer += [(370, 807)]
    outer += cpoints((370, 807), (328, 782), (309, 744), (309, 696), 16)[1:]
    outer += cpoints((309, 696), (309, 648), (326, 609), (368, 585), 16)[1:]
    outer += cpoints((368, 585), (384, 562), (396, 520), (423, 464), 10)[1:]
    d.polygon(sp(outer), fill=grey)

    # White details, closely matching the original three-panel interior.
    d.polygon(sp([(424, 520), (446, 558), (403, 558)]), fill=white)
    d.rounded_rectangle(rect(405, 545, 444, 559), radius=7 * SCALE, fill=white)
    d.polygon(sp([(354, 615), (404, 589), (423, 581), (445, 590), (498, 615), (464, 645), (423, 662), (382, 645)]), fill=white)
    d.pieslice(rect(329, 643, 424, 771), 94, 269, fill=white)
    d.pieslice(rect(422, 643, 523, 771), -89, 86, fill=white)
    d.rounded_rectangle(rect(402, 796, 444, 917), radius=7 * SCALE, fill=white)

    # Restore the grey dividers with the thinner rounded look of the reference.
    d.line(sp([(423, 663), (423, 790)]), fill=grey, width=13 * SCALE)
    d.line(sp([(423, 663), (345, 624)]), fill=grey, width=13 * SCALE)
    d.line(sp([(423, 663), (500, 624)]), fill=grey, width=13 * SCALE)


def draw_arrow(d):
    red = rgba(RED)
    white = rgba(WHITE)

    # Original outer bounds: x 676..906, y 89..979.
    d.rounded_rectangle(rect(773, 315, 802, 979), radius=12 * SCALE, fill=red)
    d.polygon(sp([(788, 89), (906, 314), (676, 314)]), fill=red)
    d.polygon(sp([(787, 143), (862, 295), (712, 295)]), fill=white)


def save_svg():
    body = f"""  <g fill="none" stroke-linecap="round" stroke-linejoin="round">
    <path fill="{GREY}" d="M103 122 L156 290 L156 914 Q156 954 111 967 Q55 954 55 914 L55 290 Z"/>
    <path fill="{WHITE}" d="M80 314 L80 872 Q107 904 134 872 L134 314 Q107 296 80 314 Z"/>

    <path fill="{GREY}" d="M423 464 C451 520 462 562 478 585 C522 605 545 648 545 696 C545 744 519 781 476 807 L476 944 Q476 964 456 964 H390 Q370 964 370 944 L370 807 C328 782 309 744 309 696 C309 648 326 609 368 585 C384 562 396 520 423 464 Z"/>
    <path fill="{WHITE}" d="M424 520 L446 558 H403 Z"/>
    <rect fill="{WHITE}" x="405" y="545" width="39" height="14" rx="7"/>
    <path fill="{WHITE}" d="M354 615 L404 589 L423 581 L445 590 L498 615 L464 645 L423 662 L382 645 Z"/>
    <path fill="{WHITE}" d="M329 707 A47.5 64 0 0 0 424 707 A47.5 64 0 0 0 329 707 Z"/>
    <path fill="{WHITE}" d="M422 707 A50.5 64 0 0 0 523 707 A50.5 64 0 0 0 422 707 Z"/>
    <rect fill="{WHITE}" x="402" y="796" width="42" height="121" rx="7"/>
    <path stroke="{GREY}" stroke-width="13" d="M423 663 V790 M423 663 L345 624 M423 663 L500 624"/>

    <rect fill="{RED}" x="773" y="315" width="29" height="664" rx="12"/>
    <path fill="{RED}" d="M788 89 L906 314 H676 Z"/>
    <path fill="{WHITE}" d="M787 143 L862 295 H712 Z"/>
  </g>"""

    svg_specs = [
        ("route-markers-original-geometry.svg", "0 0 956 1124"),
        ("slender-marker.svg", "55 122 112 845"),
        ("beacon-marker.svg", "309 464 236 500"),
        ("arrow-marker.svg", "676 89 230 890"),
    ]
    for name, viewbox in svg_specs:
        (OUT / name).write_text(
            f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="{viewbox}">
{body}
</svg>
""",
            encoding="utf-8",
        )


def main():
    canvas = new_canvas()
    draw = ImageDraw.Draw(canvas)
    draw_slender(draw)
    draw_beacon(draw)
    draw_arrow(draw)

    full = downsample(canvas, SOURCE_SIZE)
    full.save(OUT / "route-markers-original-geometry.png")
    full.save(OUT / "route-markers-preview.png")

    crop_and_save(canvas, SLENDER_BOUNDS, "slender-marker.png")
    crop_and_save(canvas, BEACON_BOUNDS, "beacon-marker.png")
    crop_and_save(canvas, ARROW_BOUNDS, "arrow-marker.png")
    save_svg()


if __name__ == "__main__":
    main()
