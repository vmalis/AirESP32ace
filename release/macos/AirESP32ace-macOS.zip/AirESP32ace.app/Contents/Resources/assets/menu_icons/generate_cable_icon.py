# AirESP32ace
# Created by VM, August 2026

from pathlib import Path

from PIL import Image, ImageDraw


OUT = Path(__file__).resolve().parent
WHITE = (255, 255, 255, 255)
SOURCE_SIZE = 200
SUPERSAMPLE = 4


def draw_icon(size):
    work_size = size * SUPERSAMPLE
    scale = work_size / SOURCE_SIZE

    def s(value):
        return round(value * scale)

    image = Image.new("RGBA", (work_size, work_size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    stroke = max(1, s(1.45))

    def rounded_rect(box, radius):
        draw.rounded_rectangle(
            tuple(s(value) for value in box),
            radius=s(radius),
            outline=WHITE,
            width=stroke,
        )

    def line(points):
        draw.line(
            [(s(x), s(y)) for x, y in points],
            fill=WHITE,
            width=stroke,
        )

    # Faithful redraw of the supplied 200 px icon, preserving its very narrow
    # USB-C connector and twin cable lines while smoothing the pixel edges.
    rounded_rect((91.0, 9.0, 108.0, 34.0), 2.2)
    rounded_rect((89.0, 34.0, 111.0, 75.0), 0.8)
    rounded_rect((93.0, 75.0, 107.0, 95.0), 0.9)
    line([(96.5, 95.0), (96.5, 200.0)])
    line([(102.5, 95.0), (102.5, 200.0)])

    return image.resize((size, size), Image.Resampling.LANCZOS)


def write_svg():
    (OUT / "cable_icon_white.svg").write_text(
        """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
  <g fill="none" stroke="#fff" stroke-width="1.45" stroke-linecap="butt" stroke-linejoin="round">
    <rect x="91" y="9" width="17" height="25" rx="2.2"/>
    <rect x="89" y="34" width="22" height="41" rx="0.8"/>
    <rect x="93" y="75" width="14" height="20" rx="0.9"/>
    <path d="M96.5 95 V200 M102.5 95 V200"/>
  </g>
</svg>
""",
        encoding="utf-8",
    )


def main():
    icon_1024 = draw_icon(1024)
    icon_1024.save(OUT / "cable_icon_white_1024.png")

    icon_466 = draw_icon(466)
    icon_466.save(OUT / "cable_icon_white_466.png")

    preview = Image.new("RGBA", (1024, 1024), (0, 0, 0, 255))
    preview.alpha_composite(icon_1024)
    preview.save(OUT / "cable_icon_white_1024_preview.png")

    write_svg()


if __name__ == "__main__":
    main()
