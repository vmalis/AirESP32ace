# Embedded airline logo fallbacks

These small transparent PNGs are firmware fallbacks for airlines whose logos
are not consistently available from the runtime AirLabs image endpoint. The
files are limited to 64 × 64 pixels so they fit the device decoder and remain
small in flash.

Operator mappings:

- `FDX` — FedEx Express
- `UPS` — UPS Airlines
- `AMZ` — Amazon Air / Prime Air branding (used only when metadata identifies Amazon)
- `DHL` — DHL-branded operators
- `CLX` — Cargolux
- `GTI` — Atlas Air
- `KE` — Korean Air / Korean Air Cargo
- `OO` — SkyWest Airlines

Logo sources:

- https://commons.wikimedia.org/wiki/File:FedEx_Express.svg
- https://commons.wikimedia.org/wiki/File:United_Parcel_Service_logo_2014.svg
- https://commons.wikimedia.org/wiki/File:Amazon_Prime_Air_logo.svg
- https://commons.wikimedia.org/wiki/File:DHL_Logo.svg
- https://commons.wikimedia.org/wiki/File:Cargolux_logo.svg
- https://commons.wikimedia.org/wiki/File:Atlas_Air_Worldwide_logo.svg
- https://commons.wikimedia.org/wiki/File:Korean_Air_Taegeuk.svg
- User-provided SkyWest Airlines wordmark asset

The marks remain trademarks of their respective owners.
